//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import java.lang.System;
import java.lang.Math;
import java.util.Scanner;

public class Grades
{
	//instance variables
	
	

	//constructor



	//set method



	private double getSum()
	{
		double sum=0.0;



		return sum;
	}

	public double getAverage()
	{
		double average=0.0;



		return average;
	}


	//toString method



}